#!/usr/bin/env node

console.log('Uninstalling nself CLI...');
console.log('Note: This only removes the npm wrapper.');
console.log('To completely remove nself, run: rm -rf ~/.nself && sudo rm -f /usr/local/bin/nself');
console.log('Or use your package manager to remove nself.');